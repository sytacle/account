# Sytacle Account Management MVP

Responsive Sytacle account-management UI built with Vite 8, React 19, Tailwind CSS 4, and Lucide React.

## Routes

- `/` — Account management dashboard
- `/login` — Sytacle sign-in UI
- `/oauth/authorize` — OAuth 2.0 authorization/consent UI

### OAuth demo

The authorize screen accepts common OAuth query parameters for UI demonstration:

`/oauth/authorize?client_id=demo-app&client_name=Acme%20App&redirect_uri=https%3A%2F%2Facme.example%2Fcallback&response_type=code&scope=openid%20profile%20email&state=abc123`

This is **UI only**. The Allow/Cancel actions do not issue authorization codes, tokens, or perform redirects. Add a real OAuth server/backend before using it for authentication.

## Development

```bash
npm install
npm run dev
```

Custom port:

```bash
npm run dev -- --port 3000
```

## Production build

```bash
npm run build
npm run preview
```
