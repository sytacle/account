import { getAuth } from "firebase/auth";
import { app } from "./index.js";

// This assumes index.js exports the initialized app, e.g.:
//   export const app = initializeApp(firebaseConfig);
// If init.js only runs initializeApp() as a side effect and doesn't
// export `app`, add that export there first.
export const auth = getAuth(app);
