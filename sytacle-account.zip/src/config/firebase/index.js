// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { initializeAppCheck, ReCaptchaV3Provider } from "firebase/app-check";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY ?? "REPLACE_ME",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN ?? "REPLACE_ME",
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL ?? "REPLACE_ME",
  projectId: import.meta.env.VITE_FIREBASE_APP_ID ?? "REPLACE_ME",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET_URL ?? "REPLACE_ME",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID ?? "REPLACE_ME",
  appId: import.meta.env.VITE_FIREBASE_APP_ID ?? "REPLACE_ME",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID ?? "REPLACE_ME",
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const analytics = getAnalytics(app);

// App Check
//
// In local development, App Check can't get a real reCAPTCHA attestation
// from localhost, so we fall back to a debug token. The SDK auto-detects
// this global and switches to debug mode regardless of which provider
// object is passed to initializeAppCheck below.
//
// First run: Firebase logs a randomly generated debug token to the
// console. Copy it into Firebase Console -> App Check -> Apps -> your
// web app -> Manage debug tokens, or it will keep being rejected.
//
// This must NEVER run in production — it bypasses App Check's entire
// purpose, so it's gated behind import.meta.env.DEV (Vite only injects
// that as true for `vite dev`, not for production builds).
if (import.meta.env.DEV) {
  self.FIREBASE_APPCHECK_DEBUG_TOKEN = true;
}

if (import.meta.env.DEV && !import.meta.env.VITE_RECAPTCHA_SITE_KEY) {
  console.warn(
    "VITE_RECAPTCHA_SITE_KEY is not set — App Check will still work in " +
      "debug mode locally, but production builds need a real reCAPTCHA " +
      "v3 site key from Firebase Console -> App Check."
  );
}

export const appCheck = initializeAppCheck(app, {
  provider: new ReCaptchaV3Provider(import.meta.env.VITE_RECAPTCHA_SITE_KEY),
  isTokenAutoRefreshEnabled: true,
});
