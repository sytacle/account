import { useState } from "react";
import {
  Bell,
  Cloud,
  CreditCard,
  HelpCircle,
  Link2,
  LockKeyhole,
  MonitorSmartphone,
  Shield,
} from "lucide-react";
import { Card, Row } from "../components/Card";

const content = {
  security: {
    title: "Security",
    subtitle: "Protect your account and control how you sign in.",
    icon: Shield,
    rows: [
      ["Password", "Change your password and keep it strong."],
      [
        "Two-factor authentication",
        "Add another layer of security to your account.",
      ],
      ["Recovery options", "Manage your recovery email and phone."],
      [
        "Recent security activity",
        "Review recent sign-ins and account changes.",
      ],
    ],
  },
  privacy: {
    title: "Privacy",
    subtitle: "Control what information you share and how it is used.",
    icon: LockKeyhole,
    rows: [
      ["Profile visibility", "Choose who can see your profile."],
      ["Activity controls", "Manage saved activity and preferences."],
      ["Personalization", "Control personalized recommendations."],
      ["Data sharing", "Review information shared with Sytacle services."],
    ],
  },
  notifications: {
    title: "Notifications",
    subtitle: "Choose what you want to be notified about.",
    icon: Bell,
    rows: [
      ["Project updates", "Comments, mentions, and activity in your projects."],
      ["Community", "Replies, follows, and new members."],
      ["Product updates", "New features, improvements, and announcements."],
      ["Marketing", "Tips, offers, and promotional content."],
    ],
  },
  devices: {
    title: "Devices",
    subtitle: "Manage devices currently signed in to your account.",
    icon: MonitorSmartphone,
    rows: [
      ["Windows PC", "Current device · Cabanatuan, Nueva Ecija"],
      ["Redmi 15C", "Active 2 hours ago"],
      ["Samsung Galaxy S24", "Active 3 days ago"],
      ["Xiaomi Pad 6", "Active 5 days ago"],
    ],
  },
  linked: {
    title: "Linked accounts",
    subtitle: "Connect and manage external accounts.",
    icon: Link2,
    rows: [
      ["Google", "Connected · john.delacruz@gmail.com"],
      ["GitHub", "Not connected"],
      ["Discord", "Not connected"],
      ["Microsoft", "Not connected"],
    ],
  },
  payments: {
    title: "Payments",
    subtitle: "Manage payment methods and billing information.",
    icon: CreditCard,
    rows: [
      ["Payment methods", "No payment methods added"],
      ["Billing profile", "Manage billing details"],
      ["Purchase history", "View Sytacle purchases and invoices"],
    ],
  },
  storage: {
    title: "Data & storage",
    subtitle: "Manage your data, storage, and downloads.",
    icon: Cloud,
    rows: [
      ["Storage usage", "2.4 GB of 15 GB used"],
      ["Export your data", "Download a copy of your Sytacle data"],
      ["Delete data", "Permanently remove selected data"],
    ],
  },
  help: {
    title: "Help",
    subtitle: "Get answers and support for your Sytacle account.",
    icon: HelpCircle,
    rows: [
      ["Help center", "Find answers to common questions"],
      ["Contact support", "Talk to a support specialist"],
      ["Send feedback", "Share your thoughts about Sytacle"],
    ],
  },
};

export default function SectionPage({ type }) {
  const data = content[type];
  const [toggles, setToggles] = useState({});
  const Icon = data.icon;
  return (
    <div className="max-w-3xl">
      <div className="mb-6 flex items-start gap-4">
        <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-blue-50 text-blue-700">
          <Icon size={24} />
        </span>
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900">
            {data.title}
          </h1>
          <p className="mt-1 text-sm leading-6 text-slate-500">
            {data.subtitle}
          </p>
        </div>
      </div>
      <Card className="divide-y divide-slate-100 overflow-hidden">
        {data.rows.map(([title, description], index) => (
          <Row
            key={title}
            title={title}
            description={description}
            action={
              ["privacy", "notifications"].includes(type) ? (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setToggles((v) => ({ ...v, [title]: !v[title] }));
                  }}
                  className={`relative h-6 w-11 shrink-0 rounded-full transition ${toggles[title] ? "bg-blue-600" : "bg-slate-200"}`}
                >
                  <span
                    className={`absolute top-1 size-4 rounded-full bg-white shadow transition ${toggles[title] ? "left-6" : "left-1"}`}
                  />
                </button>
              ) : (
                <span className="text-lg text-slate-400">›</span>
              )
            }
          />
        ))}
      </Card>
      {(type === "devices" || type === "security") && (
        <button className="mt-5 rounded-full border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
          Sign out of all devices
        </button>
      )}
    </div>
  );
}
