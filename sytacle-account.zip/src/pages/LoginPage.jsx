import { useState } from "react";
import { ArrowRight, Eye, EyeOff, ShieldCheck } from "lucide-react";
import Logo from "../components/Logo";

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className="min-h-screen bg-white text-slate-900">
      <header className="flex h-16 items-center justify-between border-b border-slate-100 px-5 sm:px-8">
        <Logo />
        <span className="text-sm text-slate-500">Sytacle Account</span>
      </header>

      <main className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-10 sm:px-6">
        <div className="w-full max-w-[430px]">
          <div className="mb-8 text-center">
            <div className="mx-auto mb-5 flex h-12 w-12 items-center justify-center rounded-full bg-blue-50 text-blue-600">
              <ShieldCheck size={25} />
            </div>
            <h1 className="text-3xl font-semibold tracking-tight text-slate-950">
              Sign in
            </h1>
            <p className="mt-2 text-sm leading-6 text-slate-500">
              Use your Sytacle Account to continue.
            </p>
          </div>

          <form
            onSubmit={(e) => e.preventDefault()}
            className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8"
          >
            <label
              className="block text-sm font-medium text-slate-800"
              htmlFor="email"
            >
              Email address
            </label>
            <input
              id="email"
              type="email"
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="mt-2 h-12 w-full rounded-xl border border-slate-300 px-4 text-sm outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10"
            />

            <button
              type="submit"
              className="mt-6 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
            >
              Sign in <ArrowRight size={17} />
            </button>

            <div className="my-6 flex items-center gap-3 text-xs text-slate-400">
              <span className="h-px flex-1 bg-slate-200" />
              OR
              <span className="h-px flex-1 bg-slate-200" />
            </div>

            <div className="d-grid gy-2">
              <button
                type="button"
                className="h-12 w-full mb-3 rounded-xl border border-slate-300 bg-white text-sm font-medium text-slate-800 hover:bg-slate-50"
              >
                Continue with GitHub
              </button>
              <button
                type="button"
                className="h-12 w-full rounded-xl border border-slate-300 bg-white text-sm font-medium text-slate-800 hover:bg-slate-50"
              >
                Continue with Google
              </button>
            </div>
          </form>

          <p className="mt-6 text-center text-sm text-slate-500">
            Don't have a Sytacle Account?{" "}
            <button className="font-medium text-blue-600 hover:text-blue-700">
              Create account
            </button>
          </p>
          <p className="mt-8 text-center text-xs leading-5 text-slate-400">
            By continuing, you agree to the Sytacle Terms of Service and Privacy
            Policy.
          </p>
        </div>
      </main>
    </div>
  );
}
