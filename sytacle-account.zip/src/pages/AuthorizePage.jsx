import { useMemo } from 'react'
import { AlertTriangle, Check, ChevronRight, ShieldCheck, X } from 'lucide-react'
import Logo from '../components/Logo'

const scopeLabels = {
  openid: ['Verify your identity', 'Use your Sytacle Account to sign you in'],
  profile: ['Basic profile information', 'Name, profile photo, and username'],
  email: ['Email address', 'View the email address associated with your account'],
  account: ['Account information', 'Access account preferences and account status'],
}

export default function AuthorizePage() {
  const params = useMemo(() => new URLSearchParams(window.location.search), [])
  const clientName = params.get('client_name') || 'Sytacle Application'
  const clientId = params.get('client_id') || 'sytacle-demo-client'
  const redirectUri = params.get('redirect_uri') || 'https://example.com/oauth/callback'
  const responseType = params.get('response_type') || 'code'
  const requestedScopes = (params.get('scope') || 'openid profile email').split(/\s+/).filter(Boolean)
  const scopes = requestedScopes.filter((scope) => scopeLabels[scope])

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="flex h-16 items-center justify-between border-b border-slate-200 bg-white px-5 sm:px-8">
        <Logo />
        <div className="flex items-center gap-2 text-xs text-slate-500"><ShieldCheck size={16} /> Secure authorization</div>
      </header>

      <main className="flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-8 sm:px-6">
        <div className="w-full max-w-[560px]">
          <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
            <div className="border-b border-slate-100 px-6 py-7 sm:px-8">
              <div className="flex items-center gap-4">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-blue-600 text-xl font-semibold text-white">S</div>
                <div className="min-w-0">
                  <p className="text-xs font-medium uppercase tracking-wider text-slate-400">OAuth 2.0</p>
                  <h1 className="mt-1 truncate text-2xl font-semibold tracking-tight text-slate-950">Authorize {clientName}</h1>
                  <p className="mt-1 truncate text-sm text-slate-500">This application wants to use your Sytacle Account.</p>
                </div>
              </div>
            </div>

            <div className="px-6 py-6 sm:px-8">
              <div className="rounded-xl bg-slate-50 p-4">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 text-blue-600"><ShieldCheck size={20} /></div>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">Signed in as Juan Dela Cruz</p>
                    <p className="mt-1 text-sm text-slate-500">juan.delacruz@example.com</p>
                  </div>
                  <button type="button" className="ml-auto text-xs font-medium text-blue-600 hover:text-blue-700">Change</button>
                </div>
              </div>

              <h2 className="mt-7 text-sm font-semibold text-slate-900">This application will be able to:</h2>
              <div className="mt-3 divide-y divide-slate-100 rounded-xl border border-slate-200">
                {scopes.length ? scopes.map(([scope, label]) => (
                  <div key={scope} className="flex items-center gap-3 p-4">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-blue-50 text-blue-600"><Check size={17} /></div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-900">{label}</p>
                      <p className="mt-0.5 text-xs leading-5 text-slate-500">{scopeLabels[scope][1]}</p>
                    </div>
                    <ChevronRight size={16} className="ml-auto shrink-0 text-slate-300" />
                  </div>
                )) : (
                  <div className="p-4 text-sm text-slate-500">No additional permissions were requested.</div>
                )}
              </div>

              <div className="mt-5 flex gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4">
                <AlertTriangle size={18} className="mt-0.5 shrink-0 text-amber-600" />
                <p className="text-xs leading-5 text-amber-800">Only authorize applications you trust. Sytacle will never share your password with this application.</p>
              </div>

              <div className="mt-6 grid grid-cols-2 gap-3">
                <button type="button" className="flex h-12 items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white text-sm font-semibold text-slate-700 hover:bg-slate-50"><X size={17} /> Cancel</button>
                <button type="button" className="flex h-12 items-center justify-center gap-2 rounded-xl bg-blue-600 text-sm font-semibold text-white hover:bg-blue-700"><Check size={17} /> Allow</button>
              </div>

              <div className="mt-6 border-t border-slate-100 pt-5 text-xs text-slate-400">
                <p>Requesting application ID</p>
                <p className="mt-1 break-all font-mono text-[11px] text-slate-500">{clientId}</p>
                <p className="mt-3">Redirect URI</p>
                <p className="mt-1 break-all font-mono text-[11px] text-slate-500">{redirectUri}</p>
                <p className="mt-3">Response type: <span className="font-mono">{responseType}</span></p>
              </div>
            </div>
          </div>

          <p className="mt-5 text-center text-xs leading-5 text-slate-400">Sytacle OAuth authorization · Review permissions before continuing</p>
        </div>
      </main>
    </div>
  )
}
