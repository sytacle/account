import {
  CalendarDays,
  CheckCircle2,
  Mail,
  Pencil,
  Phone,
  UserRound,
} from "lucide-react";
import { account, linkedAccounts } from "../data/account";
import { Card, Row } from "../components/Card";

function ProfileCard() {
  return (
    <Card className="overflow-hidden">
      <div className="p-5 sm:p-6">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
          <div className="grid size-20 shrink-0 place-items-center rounded-full bg-blue-600 text-2xl font-semibold text-white">
            JD
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="text-xl font-semibold text-slate-900">
              {account.name}
            </h2>
            <p className="mt-1 truncate text-sm text-slate-500">
              {account.email}
            </p>
            <span className="mt-2 inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-700">
              <CheckCircle2 size={13} /> Verified
            </span>
          </div>
          <button className="inline-flex items-center justify-center gap-2 rounded-full border border-blue-200 px-4 py-2 text-sm font-medium text-blue-700 hover:bg-blue-50">
            <Pencil size={15} /> Edit profile
          </button>
        </div>
        <div className="mt-6 grid border-t border-slate-100 pt-5 sm:grid-cols-2 lg:grid-cols-4">
          <Info icon={UserRound} label="Full name" value={account.name} />
          <Info icon={Mail} label="Email address" value={account.email} />
          <Info icon={Phone} label="Phone number" value={account.phone} />
          <Info icon={CalendarDays} label="Birthday" value="Not set" />
        </div>
      </div>
    </Card>
  );
}
function Info({ icon: Icon, label, value }) {
  return (
    <div className="flex gap-3 border-slate-100 py-2 sm:border-r sm:px-4 first:pl-0 last:border-0">
      <Icon className="mt-0.5 text-slate-500" size={17} />
      <div className="min-w-0">
        <p className="text-xs text-slate-500">{label}</p>
        <p className="mt-1 truncate text-sm font-medium text-slate-800">
          {value}
        </p>
      </div>
    </div>
  );
}

function SecurityCard() {
  return (
    <Card>
      <CardTitle
        title="Account security"
        subtitle="Keep your account safe and secure."
      />
      <div className="divide-y divide-slate-100">
        <Row title="Password" description="Last changed 3 months ago" />
        <Row
          title="Two-factor authentication"
          description="An extra layer of protection"
          value="Enabled"
        />
        <Row
          title="Recovery options"
          description="Keep access to your account"
          value={account.phone}
        />
      </div>
    </Card>
  );
}
function LinkedCard() {
  return (
    <Card>
      <CardTitle
        title="Linked accounts"
        subtitle="Connect your accounts for a better experience."
      />
      <div className="divide-y divide-slate-100">
        {linkedAccounts.map((item) => (
          <div key={item.name} className="flex items-center gap-3 px-5 py-3.5">
            <span className="grid size-9 place-items-center rounded-full bg-slate-100 text-xs font-bold text-slate-700">
              {item.mark}
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-slate-900">{item.name}</p>
              <p className="truncate text-xs text-slate-500">{item.email}</p>
            </div>
            {item.connected ? (
              <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-[11px] font-medium text-emerald-700">
                Connected
              </span>
            ) : (
              <button className="rounded-full border border-blue-200 px-3 py-1 text-xs font-medium text-blue-700 hover:bg-blue-50">
                Connect
              </button>
            )}
          </div>
        ))}
      </div>
    </Card>
  );
}
function CardTitle({ title, subtitle }) {
  return (
    <div className="border-b border-slate-100 px-5 py-5">
      <h3 className="font-semibold text-slate-900">{title}</h3>
      <p className="mt-1 text-xs text-slate-500">{subtitle}</p>
    </div>
  );
}

export default function AccountPage() {
  return (
    <div className="space-y-5">
      <ProfileCard />
      <div className="grid gap-5 xl:grid-cols-2">
        <SecurityCard />
        <LinkedCard />
      </div>
      <div className="grid gap-5 lg:grid-cols-3">
        <SmallCard
          title="Privacy & personalization"
          text="Control activity, visibility, and personalization."
        />
        <SmallCard
          title="Devices"
          text="Review devices currently signed in to your account."
        />
        <SmallCard
          title="Help & support"
          text="Find answers or contact the Sytacle support team."
        />
      </div>
    </div>
  );
}
function SmallCard({ title, text }) {
  return (
    <Card className="p-5">
      <h3 className="font-semibold text-slate-900">{title}</h3>
      <p className="mt-1 text-sm leading-6 text-slate-500">{text}</p>
      <button className="mt-4 text-sm font-medium text-blue-700">
        Manage →
      </button>
    </Card>
  );
}
