import {
  Bell,
  Cloud,
  CreditCard,
  HelpCircle,
  Link2,
  LockKeyhole,
  MonitorSmartphone,
  Shield,
  UserRound,
} from 'lucide-react'

export const account = {
  name: 'Juan Dela Cruz',
  email: 'juan.delacruz@example.com',
  phone: '+63 9XX XXX XXXX',
  username: 'juandelacruz',
  verified: true,
}

export const navItems = [
  { id: 'account', label: 'My Account', icon: UserRound },
  { id: 'security', label: 'Security', icon: Shield },
  { id: 'privacy', label: 'Privacy', icon: LockKeyhole },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'devices', label: 'Devices', icon: MonitorSmartphone },
  { id: 'linked', label: 'Linked accounts', icon: Link2 },
  { id: 'payments', label: 'Payments', icon: CreditCard },
  { id: 'storage', label: 'Data & storage', icon: Cloud },
  { id: 'help', label: 'Help', icon: HelpCircle },
]

export const linkedAccounts = [
  { name: 'Google', email: 'john.delacruz@gmail.com', connected: true, mark: 'G' },
  { name: 'GitHub', email: 'Not connected', connected: false, mark: 'GH' },
  { name: 'Discord', email: 'Not connected', connected: false, mark: 'D' },
  { name: 'Microsoft', email: 'Not connected', connected: false, mark: 'M' },
  { name: 'Apple', email: 'Not connected', connected: false, mark: '' },
]
