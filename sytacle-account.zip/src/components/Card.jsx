export function Card({ children, className = '' }) {
  return <section className={`rounded-2xl border border-slate-200 bg-white ${className}`}>{children}</section>
}

export function Row({ icon: Icon, title, description, value, action, onClick, danger = false }) {
  return (
    <button onClick={onClick} className={`group flex w-full items-center gap-4 px-5 py-4 text-left transition hover:bg-slate-50 ${danger ? 'text-red-600' : ''}`}>
      {Icon && <span className={`grid size-9 shrink-0 place-items-center rounded-full ${danger ? 'bg-red-50' : 'bg-slate-100'} ${danger ? 'text-red-500' : 'text-slate-600'}`}><Icon size={18} /></span>}
      <span className="min-w-0 flex-1">
        <span className="block text-sm font-medium text-slate-900">{title}</span>
        {description && <span className="mt-0.5 block text-xs leading-5 text-slate-500">{description}</span>}
      </span>
      {value && <span className="hidden text-xs text-slate-500 sm:block">{value}</span>}
      {action || <span className="text-lg text-slate-400 transition group-hover:translate-x-0.5">›</span>}
    </button>
  )
}
