import {
  Grid2X2,
  Menu,
  Moon,
  Search,
  Sun,
  Monitor,
} from "lucide-react";
import Logo from "./Logo";
import { useTheme } from "../hooks/useTheme";

export default function Header({ onMenu }) {
  const { theme, setTheme } = useTheme();

  const cycleTheme = () => {
    if (theme === "light") {
      setTheme("dark");
    } else if (theme === "dark") {
      setTheme("system");
    } else {
      setTheme("light");
    }
  };

  const ThemeIcon =
    theme === "dark"
      ? Moon
      : theme === "light"
        ? Sun
        : Monitor;

  return (
    <header
      className="
        sticky top-0 z-30 flex h-16 items-center
        border-b border-slate-200/80
        bg-white/95 px-4 backdrop-blur
        dark:border-slate-800
        dark:bg-slate-950/95
        md:px-6
      "
    >
      <button
        onClick={onMenu}
        className="
          mr-3 rounded-full p-2
          text-slate-600 hover:bg-slate-100
          dark:text-slate-300 dark:hover:bg-slate-800
          md:hidden
        "
        aria-label="Open menu"
      >
        <Menu size={22} />
      </button>

      <div className="md:hidden">
        <Logo compact />
      </div>

      <div className="hidden md:block">
        <Logo />
      </div>

      <div className="mx-auto hidden w-full max-w-xl px-8 lg:block">
        <div
          className="
            flex h-11 items-center gap-3 rounded-full
            bg-slate-100 px-4 text-sm text-slate-500
            focus-within:bg-white
            focus-within:ring-2 focus-within:ring-blue-100
            dark:bg-slate-900
            dark:text-slate-400
            dark:focus-within:bg-slate-900
            dark:focus-within:ring-blue-900/50
          "
        >
          <Search size={18} />

          <input
            className="
              w-full bg-transparent outline-none
              placeholder:text-slate-500
              dark:text-slate-200
              dark:placeholder:text-slate-500
            "
            placeholder="Search Sytacle or settings"
          />

          <kbd
            className="
              rounded border border-slate-200
              bg-white px-1.5 py-0.5
              text-[10px] text-slate-400
              dark:border-slate-700
              dark:bg-slate-800
              dark:text-slate-500
            "
          >
            Ctrl K
          </kbd>
        </div>
      </div>

      <div className="ml-auto flex items-center gap-1 sm:gap-2">
        {/* Theme switcher */}
        <button
          onClick={cycleTheme}
          className="
            rounded-full p-2
            text-slate-600 hover:bg-slate-100
            dark:text-slate-300 dark:hover:bg-slate-800
          "
          aria-label={`Theme: ${theme}. Click to change theme`}
          title={`Theme: ${theme}`}
        >
          <ThemeIcon size={20} />
        </button>

        {/* Apps */}
        <button
          className="
            hidden rounded-full p-2
            text-slate-600 hover:bg-slate-100
            dark:text-slate-300 dark:hover:bg-slate-800
            sm:block
          "
          aria-label="Apps"
        >
          <Grid2X2 size={20} />
        </button>

        {/* Account */}
        <button
          className="
            grid size-9 place-items-center
            rounded-full bg-blue-600
            text-sm font-semibold text-white
          "
          aria-label="Account"
        >
          JD
        </button>
      </div>
    </header>
  );
}